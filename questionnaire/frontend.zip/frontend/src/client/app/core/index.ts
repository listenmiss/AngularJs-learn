/**
 * This barrel file provides the exports for the core resources (services, components).
 */
export * from './navbar/index';

